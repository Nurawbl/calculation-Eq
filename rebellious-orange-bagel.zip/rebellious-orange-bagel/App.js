import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  Button,
  StyleSheet,
} from 'react-native';
import Svg, { Line, Polyline } from 'react-native-svg';

export default function App() {
  const [x, setX] = useState("0");   // хранится как строка
  const [y, setY] = useState(null);

  const calculateY = (value) => {
    const num = Number(value);
    if (isNaN(num)) return null;   // защита от NaN
    if (num >= 0) return num * num;
    return 2 * num + 1;
  };

  const handleCalculate = () => {
    setY(calculateY(x));
  };

  // Graph data
  const points = [];
  for (let i = -10; i <= 10; i++) {
    const yVal = calculateY(i);
    points.push(`${i * 10 + 150},${150 - yVal * 5}`);
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Шарты бар теңдеу</Text>

      {/* Таблица */}
      <View style={styles.table}>
        <View style={styles.row}>
          <Text style={styles.cell}>x мәні</Text>
          <TextInput
            style={styles.input}
            keyboardType="numeric"
            value={x}                        // теперь строка
            onChangeText={(val) => setX(val)} // сохраняем как строку
          />
        </View>

        <View style={styles.row}>
          <Text style={styles.cell}>y нәтижесі</Text>
          <Text style={styles.result}>{y !== null ? y : '-'}</Text>
        </View>
      </View>

      <Button title="Есептеу" onPress={handleCalculate} />

      {/* График */}
      <Text style={styles.subtitle}>x–y графигі</Text>
      <View style={styles.graph}>
        <Svg height="300" width="300">
          {/* Оси */}
          <Line x1="0" y1="150" x2="300" y2="150" stroke="black" />
          <Line x1="150" y1="0" x2="150" y2="300" stroke="black" />

          {/* Функция */}
          <Polyline
            points={points.join(' ')}
            fill="none"
            stroke="blue"
            strokeWidth="2"
          />
        </Svg>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 15,
    backgroundColor: '#f5f5f5',
  },
  title: {
    fontSize: 22,
    textAlign: 'center',
    fontWeight: 'bold',
    marginBottom: 15,
  },
  table: {
    borderWidth: 1,
    borderColor: '#999',
    marginBottom: 15,
  },
  row: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderColor: '#ccc',
  },
  cell: {
    flex: 1,
    padding: 10,
    fontSize: 16,
  },
  input: {
    flex: 1,
    padding: 10,
    backgroundColor: '#fff',
    borderLeftWidth: 1,
    borderColor: '#ccc',
  },
  result: {
    flex: 1,
    padding: 10,
    fontSize: 16,
    fontWeight: 'bold',
  },
  subtitle: {
    marginTop: 20,
    fontSize: 18,
    textAlign: 'center',
  },
  graph: {
    alignItems: 'center',
    marginTop: 10,
  },
});
